"use client"

import { useEffect, useState } from "react"
import { Button } from "@/components/ui/button"
import { ArrowDown, Github, Linkedin, Mail } from "lucide-react"

export function Hero() {
  const [isVisible, setIsVisible] = useState(false)
  const [displayName, setDisplayName] = useState("santtitoz")
  const [isAnimating, setIsAnimating] = useState(false)

  useEffect(() => {
    setIsVisible(true)
  }, [])

  const handleNameHover = () => {
    if (isAnimating) return

    setIsAnimating(true)
    const originalName = "santtitoz"
    const newName = "Eliabi Santos"

    // Fase 1: Apagar da direita para esquerda
    let currentText = originalName
    const eraseInterval = setInterval(() => {
      currentText = currentText.slice(0, -1)
      setDisplayName(currentText)

      if (currentText === "") {
        clearInterval(eraseInterval)

        // Fase 2: Escrever o novo nome
        let index = 0
        const writeInterval = setInterval(() => {
          setDisplayName(newName.slice(0, index + 1))
          index++

          if (index === newName.length) {
            clearInterval(writeInterval)
            setIsAnimating(false)
          }
        }, 100)
      }
    }, 80)
  }

  const handleNameLeave = () => {
    if (isAnimating) return

    setIsAnimating(true)
    const currentText = displayName
    const originalName = "santtitoz"

    // Apagar texto atual
    let text = currentText
    const eraseInterval = setInterval(() => {
      text = text.slice(0, -1)
      setDisplayName(text)

      if (text === "") {
        clearInterval(eraseInterval)

        // Escrever nome original
        let index = 0
        const writeInterval = setInterval(() => {
          setDisplayName(originalName.slice(0, index + 1))
          index++

          if (index === originalName.length) {
            clearInterval(writeInterval)
            setIsAnimating(false)
          }
        }, 100)
      }
    }, 80)
  }

  const scrollToAbout = () => {
    const aboutSection = document.getElementById("about")
    if (aboutSection) {
      aboutSection.scrollIntoView({ behavior: "smooth" })
    }
  }

  return (
    <section id="home" className="min-h-screen flex items-center justify-center relative overflow-hidden">
      <div className="container max-w-6xl mx-auto px-6 text-center">
        <div className={`transition-all duration-1000 ${isVisible ? "animate-fade-in-up opacity-100" : "opacity-0"}`}>
          <div className="mb-6">
            <h1 className="text-3xl md:text-5xl font-black text-balance mb-3 leading-tight font-mono tracking-tight flex items-center justify-center">
              <span
                className="bg-gradient-to-r from-primary via-primary/80 to-primary/60 bg-clip-text text-transparent drop-shadow-sm cursor-pointer transition-all duration-300 hover:scale-105"
                onMouseEnter={handleNameHover}
                onMouseLeave={handleNameLeave}
              >
                {displayName}
              </span>
            </h1>
            <div className="w-16 h-1 bg-gradient-to-r from-primary via-primary/80 to-primary/60 mx-auto rounded-full shadow-sm"></div>
          </div>

          <p
            className={`text-base md:text-lg text-muted-foreground mb-8 max-w-xl mx-auto text-balance font-light leading-relaxed duration-1000 delay-200 hidden md:block ${isVisible ? "animate-fade-in-up opacity-100" : "opacity-0"}`}
          >
            Web Designer & Developer Junior especializado em criar experiências digitais únicas e funcionais
          </p>

          <div
            className={`flex flex-col sm:flex-row items-center justify-center gap-4 mb-12 duration-1000 delay-400 ${isVisible ? "animate-fade-in-up opacity-100" : "opacity-0"}`}
          >
            <Button
              size="lg"
              className="group px-6 py-5 h-auto text-base font-medium rounded-2xl bg-primary hover:bg-primary/90 shadow-md hover:shadow-lg hover:scale-105 transition-all duration-300 font-sans"
            >
              Ver Projetos
              <ArrowDown className="ml-2 h-4 w-4 group-hover:translate-y-1 transition-transform" />
            </Button>

            <div className="flex items-center gap-2">
              <a
                href="https://github.com/santtitoz"
                target="_blank"
                rel="noopener noreferrer"
                className="p-4 h-12 w-12 flex items-center justify-center rounded-2xl bg-background/50 border border-border/30 backdrop-blur-sm hover:bg-primary/10 hover:border-primary/30 transition-all duration-300 group shadow-sm hover:shadow-md hover:scale-110"
              >
                <Github className="h-5 w-5 text-muted-foreground group-hover:text-primary transition-colors" />
              </a>
              <a
                href="https://www.linkedin.com/in/santtitoz/"
                target="_blank"
                rel="noopener noreferrer"
                className="p-4 h-12 w-12 flex items-center justify-center rounded-2xl bg-background/50 border border-border/30 backdrop-blur-sm hover:bg-primary/10 hover:border-primary/30 transition-all duration-300 group shadow-sm hover:shadow-md hover:scale-110"
              >
                <Linkedin className="h-5 w-5 text-muted-foreground group-hover:text-primary transition-colors" />
              </a>
              <a
                href="mailto:esanttitoz@gmail.com"
                className="p-4 h-12 w-12 flex items-center justify-center rounded-2xl bg-background/50 border border-border/30 backdrop-blur-sm hover:bg-primary/10 hover:border-primary/30 transition-all duration-300 group shadow-sm hover:shadow-md hover:scale-110"
              >
                <Mail className="h-5 w-5 text-muted-foreground group-hover:text-primary transition-colors" />
              </a>
            </div>
          </div>
        </div>

        <div className="absolute bottom-8 left-1/2 transform -translate-x-1/2 animate-bounce">
          <Button variant="ghost" size="icon" onClick={scrollToAbout} className="rounded-full">
            <ArrowDown className="h-6 w-6" />
          </Button>
        </div>
      </div>

      {/* Floating elements for visual interest */}
      <div className="absolute top-20 left-10 w-20 h-20 bg-secondary/30 rounded-full animate-float"></div>
      <div className="absolute top-40 right-20 w-16 h-16 bg-accent/20 rounded-full animate-float animate-delay-200"></div>
      <div className="absolute bottom-40 left-20 w-12 h-12 bg-primary/20 rounded-full animate-float animate-delay-400"></div>
    </section>
  )
}
