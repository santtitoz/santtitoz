"use client"

import { useState, useEffect, useRef } from "react"
import { ExternalLink, Github, ArrowUpRight } from "lucide-react"
import { type CarouselApi, Carousel, CarouselContent, CarouselItem } from "@/components/ui/carousel"

type Project = {
  title: string
  description: string
  tech: string[]
  github: string
  live: string
  images: string[]
}

function ProjectCard({ project, index }: { project: Project; index: number }) {
  const [api, setApi] = useState<CarouselApi>()
  const [isVisible, setIsVisible] = useState(false)
  const [previewKey, setPreviewKey] = useState(0)
  const cardRef = useRef<HTMLDivElement>(null)

  useEffect(() => {
    const observer = new IntersectionObserver(
      ([entry]) => {
        if (entry.isIntersecting) {
          setIsVisible(true)
        }
      },
      { threshold: 0.1 }
    )

    if (cardRef.current) {
      observer.observe(cardRef.current)
    }

    return () => observer.disconnect()
  }, [])

  const resetPreview = () => {
    setPreviewKey(prev => prev + 1)
  }

  return (
    <div
      ref={cardRef}
      className={`group flex flex-col bg-muted/30 rounded-3xl border border-border/40 overflow-hidden hover:border-primary/20 transition-all duration-700 ${isVisible ? "opacity-100 translate-y-0" : "opacity-0 translate-y-10"}`}
    >
      {/* Preview Section */}
      <div
        className="aspect-[16/10] w-full relative overflow-hidden bg-background/50 border-b border-border/40 group-hover:bg-background/80 transition-colors"
        onMouseLeave={resetPreview}
      >
        {project.live && project.live !== "#" ? (
          <div className="w-full h-full overflow-hidden relative">
            {/* Scaled Desktop Preview */}
            <iframe
              key={previewKey}
              src={project.live}
              title={`Preview of ${project.title}`}
              className="absolute top-0 left-0 w-[200%] h-[200%] border-0 bg-white"
              style={{ transform: 'scale(0.5)', transformOrigin: 'top left' }}
              loading="lazy"
              sandbox="allow-scripts allow-same-origin allow-popups allow-forms"
            />
          </div>
        ) : (
          <Carousel setApi={setApi} className="w-full h-full">
            <CarouselContent className="h-full ml-0">
              {project.images.map((img, imgIndex) => (
                <CarouselItem key={imgIndex} className="h-full pl-0">
                  <div
                    className="w-full h-full overflow-hidden hover:overflow-y-auto custom-scrollbar"
                    onMouseLeave={(e) => e.currentTarget.scrollTo({ top: 0, behavior: 'smooth' })}
                  >
                    <img
                      src={img || "/placeholder.svg"}
                      alt={`${project.title} screenshot ${imgIndex + 1}`}
                      className="w-full h-auto object-cover object-top block"
                    />
                  </div>
                </CarouselItem>
              ))}
            </CarouselContent>
          </Carousel>
        )}
      </div>

      {/* Info Section */}
      <div className="p-8 flex flex-col flex-1 gap-6">
        <div className="space-y-3">
          <div className="flex items-start justify-between gap-4">
            <h3 className="text-2xl font-bold text-foreground leading-tight">{project.title}</h3>
            <a
              href={project.live}
              target="_blank"
              rel="noopener noreferrer"
              className="p-2 rounded-full bg-background border border-border/50 text-muted-foreground hover:text-primary hover:border-primary transition-colors hover:rotate-45 duration-300"
              title="Visit Site"
            >
              <ArrowUpRight size={20} />
            </a>
          </div>
          <p className="text-muted-foreground text-sm leading-relaxed font-light">{project.description}</p>
        </div>

        <div className="mt-auto space-y-6">
          <div className="flex flex-wrap gap-2">
            {project.tech.map((tech) => (
              <span
                key={tech}
                className="px-3 py-1 text-xs font-medium font-mono text-muted-foreground bg-background/50 rounded-lg border border-border/40"
              >
                {tech}
              </span>
            ))}
          </div>

          <div className="flex items-center gap-4 pt-2 border-t border-border/40">
            <a
              href={project.github}
              target="_blank"
              rel="noopener noreferrer"
              className="flex items-center gap-2 text-xs font-bold uppercase tracking-wider text-muted-foreground hover:text-foreground transition-colors"
            >
              <Github size={16} />
              Source Code
            </a>
            {project.live && project.live !== "#" && (
              <a
                href={project.live}
                target="_blank"
                rel="noopener noreferrer"
                className="flex items-center gap-2 text-xs font-bold uppercase tracking-wider text-muted-foreground hover:text-foreground transition-colors"
              >
                <ExternalLink size={16} />
                Live Preview
              </a>
            )}
          </div>
        </div>
      </div>
    </div>
  )
}

export function Projects() {
  const projects = [
    {
      title: "Costanza",
      description:
        "O Costanza foi criado com o intuito de dominar linguagens de programação através de desafios, conquistar ranks, ganhar XP e compartilhar seus projetos com uma comunidade de desenvolvedores.",
      tech: ["Next.js", "TypeScript", "React", "Tailwind CSS"],
      github: "https://github.com/santtitoz/costanza",
      live: "https://costanza-taupe.vercel.app",
      images: [
        "/costanza/image-1.png",
        "/costanza/image-2.png",
        "/costanza/image-3.png",
        "/costanza/image-4.png",
        "/costanza/image-5.png",
      ],
    },
    {
      title: "E-commerce Moderno",
      description:
        "Plataforma completa de e-commerce com carrinho de compras, pagamentos integrados e painel administrativo.",
      tech: ["Next.js", "TypeScript", "React", "Redux"],
      github: "#",
      live: "#",
      images: [
        "/modern-ecommerce-interface.png",
        "/productivity-app-interface.png",
        "/analytics-dashboard.png",
      ],
    },
    {
      title: "Dashboard Analytics",
      description:
        "Dashboard interativo para análise de dados em tempo real com gráficos dinâmicos e métricas de performance.",
      tech: ["React", "Node.js", "Express", "JavaScript"],
      github: "#",
      live: "#",
      images: [
        "/analytics-dashboard.png",
        "/modern-ecommerce-interface.png",
        "/productivity-app-interface.png",
      ],
    },
    {
      title: "App de Produtividade",
      description: "Aplicativo completo para gerenciamento de tarefas, projetos e equipes com sistema de notificações.",
      tech: ["React", "Redux", "JavaScript", "Node.js"],
      github: "#",
      live: "#",
      images: [
        "/productivity-app-interface.png",
        "/analytics-dashboard.png",
        "/modern-ecommerce-interface.png",
      ],
    },
  ]

  return (
    <section id="projects" className="bg-background relative py-20">
      <div className="container max-w-6xl mx-auto px-6 mb-16 text-center">
        <h2 className="text-3xl md:text-5xl font-black mb-4 tracking-tight">
          Selected Works
        </h2>
        <p className="text-muted-foreground text-lg max-w-2xl mx-auto font-light">
          Projetos que definem minha jornada e evolução técnica.
        </p>
      </div>

      <div className="container max-w-6xl mx-auto px-6">
        <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
          {projects.map((project, index) => (
            <ProjectCard key={project.title} project={project} index={index} />
          ))}
        </div>
      </div>
    </section>
  )
}
